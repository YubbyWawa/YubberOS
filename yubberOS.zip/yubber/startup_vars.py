Apps = """
[!]About
[#]Calculater
[<<.]Magwah"""

